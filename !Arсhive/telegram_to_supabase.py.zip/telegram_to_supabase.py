#!/usr/bin/env python3
"""
Telegram to Supabase Importer
Простой скрипт для импорта сообщений из Telegram в Supabase
"""

from telethon import TelegramClient
from telethon.sessions import StringSession
import asyncio
import os
import json
from datetime import datetime
import httpx
import sys

from telethon.tl.functions.channels import GetForumTopicsRequest
from telethon.tl.types import InputChannel

def print_header():
    print("="*60)
    print("ТЕЛЕГРАМ ИМПОРТЕР ДЛЯ SUPABASE")
    print("Использует Telethon для получения сообщений")
    print("="*60)

def print_success(message):
    print(f"✅ {message}")

def print_error(message):
    print(f"❌ {message}")

def print_info(message):
    print(f"ℹ️  {message}")

def load_config():
    """Загружает конфигурацию из .env или переменных окружения"""
    # Попробуем загрузить .env файл из родительской директории
    env_paths = ['.env', '../.env']  # Ищем сначала в текущей, потом в родительской
    
    for env_path in env_paths:
        try:
            with open(env_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key] = value.replace('"', '').replace("'", "")
            break  # Если файл найден и прочитан, выходим из цикла
        except FileNotFoundError:
            continue  # Пробуем следующий путь

    # Загружаем конфигурацию
    config = {
        'api_id': os.getenv('TELEGRAM_API_ID', '').strip(),
        'api_hash': os.getenv('TELEGRAM_API_HASH', '').strip(),
        'session_string': os.getenv('TELEGRAM_SESSION', '').strip(),
        'supabase_url': os.getenv('MY_SUPABASE_URL', '').strip(),
        'supabase_key': os.getenv('MY_SUPABASE_SERVICE_ROLE_KEY', '').strip()
    }

    # Проверяем наличие всех необходимых параметров
    missing = [key for key, value in config.items() if not value]
    if missing:
        print_error(f"Отсутствуют следующие переменные: {', '.join(missing)}")
        print("\nПожалуйста, установите переменные окружения:")
        print("  TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION")
        print("  MY_SUPABASE_URL, MY_SUPABASE_SERVICE_ROLE_KEY")
        return None
    
    try:
        config['api_id'] = int(config['api_id'])
    except ValueError:
        print_error("TELEGRAM_API_ID должен быть числом")
        return None

    return config

OLLAMA_API_URL = os.getenv('OLLAMA_API_URL', 'http://127.0.0.1:11434/api/generate')
OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'gemma3:latest')

async def classify_message_with_ollama(message_content: str) -> bool:
    """
    Classifies a message as an event or non-event using Ollama, specifically checking for a concrete event date.
    """
    prompt = f"ИНСТРУКЦИЯ: Ты — строгий классификатор. Твоя задача — определить, содержит ли предоставленный ниже текст КОНКРЕТНУЮ дату (например, 26 апреля, 12.05.2025, 10/04, 10.04) или ОТНОСИТЕЛЬНУЮ дату/время события (например, \"завтра в 19:00\", \"в эту субботу\", \"через неделю\"). Отвечай только одним boolean значением: 'TRUE' или 'FALSE'. Не добавляй никаких пояснений, знаков препинания или других символов.\n\nСообщение: {message_content}"
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                OLLAMA_API_URL,
                json={
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False
                },
                timeout=30.0
            )
            response.raise_for_status()
            result = response.json()
            
            # Ollama responses can vary, try to extract the most likely answer
            # Assuming the response will contain "ДА" or "НЕТ"
            if "response" in result:
                ollama_response = result["response"].strip().upper()
                if "TRUE" in ollama_response:
                    return True
                elif "FALSE" in ollama_response:
                    return False
                print_error(f"Неожиданный ответ от Ollama (не содержит TRUE/FALSE): {ollama_response}")
            else:
                print_error(f"Неожиданный ответ от Ollama (нет поля 'response'): {result}")
            return False
            
            print_error(f"Неожиданный ответ от Ollama: {result}")
            return False
        except httpx.RequestError as e:
            print_error(f"Ошибка запроса к Ollama: {e}")
            return False
        except httpx.HTTPStatusError as e:
            print_error(f"Ошибка HTTP статуса от Ollama: {e.response.status_code} - {e.response.text}")
            return False
        except Exception as e:
            print_error(f"Неизвестная ошибка при классификации Ollama: {e}")
            return False

async def import_telegram_messages():
    """Основная функция импорта сообщений"""
    config = load_config()
    if not config:
        return None

    print_info("Подключение к Telegram...")
    client = TelegramClient(
        StringSession(config['session_string']),
        config['api_id'],
        config['api_hash']
    )
    
    await client.connect()
    
    try:
        # Проверим, подключились ли мы
        me = await client.get_me()
        print_success(f"Подключились как: {me.first_name} (@{me.username or 'N/A'})")
        
        print_info("Подключение к Supabase...")
        
        async with httpx.AsyncClient() as http_client:
            headers = {
                'apikey': config['supabase_key'],
                'Authorization': f"Bearer {config['supabase_key']}",
                'Content-Type': 'application/json'
            }

            # Получаем каналы для синхронизации
            print_info("Получение списка каналов...")
            response = await http_client.get(
                f"{config['supabase_url']}/rest/v1/channel_sync_state?select=*",
                headers=headers
            )
            
            if response.status_code != 200:
                print_error(f"Ошибка получения каналов: {response.text}")
                return None

            channels = response.json()
            print_success(f"Найдено {len(channels)} каналов для синхронизации")
            
            total_synced = 0
            total_messages = 0
            total_events_classified = 0
            
            for channel in channels:
                channel_name = channel.get('channel_name', str(channel['channel_id']))
                print_info(f"Обработка канала: {channel_name}")
                
                try:
                    # Попробуем получить сущность по числовому ID
                    # Для каналов может потребоваться особый формат
                    channel_id = int(channel['channel_id'])
                    try:
                        # Попробуем получить сущность по числовому ID
                        entity = await client.get_entity(channel_id)
                    except ValueError:
                        # Если числовое значение не работает, пробуем получить по имени
                        channel_name = channel.get('channel_name', '').strip()
                        if channel_name and channel_name.startswith('@'):
                            print_info(f"  Попытка получить канал по имени: {channel_name}")
                            entity = await client.get_entity(channel_name)
                        else:
                                                # Попробуем сформировать специальный PeerChannel объект
                                                from telethon.tl.types import PeerChannel
                                                entity = await client.get_entity(PeerChannel(channel_id))
                                                
                                                # !!! ИСПРАВЛЕНИЕ 1: ОПРЕДЕЛЕНИЕ last_id !!!
                                                last_id = channel.get('last_processed_message_id', 0) or 0
                                                
                                                # 2. Определение списка ID топиков для обработки                    thread_ids_to_process = []
                    specific_thread_id = channel.get('thread_id')

                    if specific_thread_id is not None:
                        thread_ids_to_process.append(specific_thread_id)
                        print_info(f"  Синхронизация конкретного топика ID={specific_thread_id}")
                    elif hasattr(entity, 'forum') and entity.forum:
                        print_info(f"  Обнаружен форум. Получение списка топиков...")
                        
                        input_channel = InputChannel(entity.id, entity.access_hash)
                        
                        forum_topics = await client(GetForumTopicsRequest(
                            channel=input_channel,
                            offset_date=0,
                            offset_id=0,
                            offset_topic=0,
                            limit=100  # Достаточно для большинства случаев
                        ))

                        # ID топика — это ID его корневого сервисного сообщения
                        new_thread_ids = [topic.id for topic in forum_topics.topics if topic.id != 1]
                        thread_ids_to_process.extend([1] + new_thread_ids) # Include General Topic
                        
                        print_success(f"  Найдено топиков: {len(thread_ids_to_process)}")
                    else:
                        thread_ids_to_process.append(None) # Для обычных каналов без топиков


                    # 3. Обходим все топики (включая General, ID=1, или None для обычных каналов)
                    max_id_overall = last_id
                    
                    for thread_id in thread_ids_to_process:
                        if thread_id is None:
                            topic_label = "Основной канал"
                            thread_id_param = None
                        elif thread_id == 1:
                            topic_label = "Общий Топик (ID=1)"
                            thread_id_param = 1
                        else:
                            topic_label = f"Топик ID={thread_id}"
                            thread_id_param = thread_id

                        print_info(f"  > Синхронизация: {topic_label}")

                        # Получаем сообщения для ЭТОГО топика
                        current_messages = await client.get_messages(
                            entity,
                            limit=20,  # Ограничиваем количество за раз
                            min_id=last_id,
                            thread_id=thread_id_param 
                        )
                        
                        if not current_messages:
                            continue
                            
                        # Подготовим сообщения для вставки
                        # Используем channel_name вместо channel_id, как в структуре таблицы
                        posts_to_insert = []
                        for msg in current_messages:
                            if msg.text:  # Только сообщения с текстом
                                is_event = await classify_message_with_ollama(msg.text)
                                post = {
                                    'channel_name': f"@{entity.username}" if hasattr(entity, 'username') and entity.username else f"channel_{entity.id}",
                                    'message_id': msg.id,
                                    'content': msg.text,
                                    'posted_at': datetime.fromtimestamp(msg.date.timestamp()).isoformat(),
                                    'is_event_filtered': True, # Mark as filtered by LLM
                                    'is_event': is_event # Result of LLM classification
                                }
                                if is_event:
                                    total_events_classified += 1
                                posts_to_insert.append(post)
                        
                        if not posts_to_insert:
                            print_info(f"  Нет текстовых сообщений для сохранения в {topic_label}")
                            continue
                        
                        # Вставляем в Supabase
                        # Если возникнет ошибка внешнего ключа, нужно обновить channel_sync_state
                        try:
                            response = await http_client.post(
                                f"{config['supabase_url']}/rest/v1/posts?select=*,is_event_filtered,is_event",
                                headers=headers,
                                json=posts_to_insert
                            )
                            
                            if response.status_code in [200, 201]:
                                print_success(f"  Вставлено {len(posts_to_insert)} сообщений в {topic_label}")
                                total_messages += len(posts_to_insert)
                                
                                # Обновляем максимальный ID для этого прохода
                                max_id_current = max(msg.id for msg in current_messages)
                                if max_id_current > max_id_overall:
                                    max_id_overall = max_id_current
                            else:
                                print_error(f"  Ошибка вставки в {topic_label}: {response.text}")
                        except Exception as insert_error:
                            print_error(f"  Ошибка вставки в {topic_label}: {insert_error}")
                            
                            # Проверим, есть ли запись в channel_sync_state для этого канала
                            # и при необходимости создадим её
                            try:
                                channel_name_for_lookup = f"@{entity.username}" if hasattr(entity, 'username') and entity.username else f"channel_{entity.id}"
                                
                                # Проверим существующую запись
                                check_response = await http_client.get(
                                    f"{config['supabase_url']}/rest/v1/channel_sync_state",
                                    headers=headers,
                                    params={'channel_name': f'eq.{channel_name_for_lookup}'} 
                                )
                                
                                if check_response.status_code == 200 and len(check_response.json()) == 0:
                                    # Нет записи для этого канала, создадим её
                                    # Обновим channel_name в постах на правильное из entity
                                    for post in posts_to_insert:
                                        post['channel_name'] = channel_name_for_lookup
                                    
                                    # Также добавим запись в channel_sync_state
                                    channel_state_data = {
                                        'channel_name': channel_name_for_lookup,
                                        'channel_id': entity.id,
                                        'last_processed_message_id': 0
                                    }
                                    
                                    await http_client.post(
                                        f"{config['supabase_url']}/rest/v1/channel_sync_state",
                                        headers=headers,
                                        json=channel_state_data
                                    )
                                    
                                    # Повторим вставку сообщений с правильным channel_name
                                    response = await http_client.post(
                                        f"{config['supabase_url']}/rest/v1/posts?select=*,is_event_filtered,is_event",
                                        headers=headers,
                                        json=posts_to_insert
                                    )
                                    
                                    if response.status_code in [200, 201]:
                                        print_success(f"  Вставлено {len(posts_to_insert)} сообщений (после обновления данных) в {topic_label}")
                                        total_messages += len(posts_to_insert)
                                        
                                        # Обновляем максимальный ID для этого прохода
                                        max_id_current = max(msg.id for msg in current_messages)
                                        if max_id_current > max_id_overall:
                                            max_id_overall = max_id_current
                                    else:
                                        print_error(f"  Ошибка вставки (после обновления данных) в {topic_label}: {response.text}")
                            except Exception as e:
                                print_error(f"  Ошибка при попытке исправить данные в {topic_label}: {e}")
                                
                    # 4. Обновление общего последнего ID (вместо старого кода обновления)
                    # Используем max_id_overall, чтобы не пропустить сообщения
                    if max_id_overall > last_id:
                        channel_name_for_update = f"@{entity.username}" if hasattr(entity, 'username') and entity.username else f"channel_{entity.id}"
                        update_response = await http_client.patch(
                            f"{config['supabase_url']}/rest/v1/channel_sync_state",
                            headers=headers,
                            params={'channel_name': f'eq.{channel_name_for_update}'},
                            json={'last_processed_message_id': max_id_overall}
                        )
                        
                        if update_response.status_code in [200, 204]:
                            print_success(f"  Состояние обновлено до: {max_id_overall}")
                            total_synced += 1
                        else:
                            print_error(f"  Ошибка обновления состояния: {update_response.text}")
                    else:
                        print_info(f"  Нет новых сообщений для обновления состояния в {channel_name}")
            
            # Возвращаем результат
            result = {
                'status': 'success',
                'channels_synced': total_synced,
                'total_channels': len(channels),
                'messages_imported': total_messages,
                'events_classified': total_events_classified,
                'timestamp': datetime.now().isoformat()
            }
            
            print_success(f"Синхронизация завершена!")
            print_info(f"Обработано каналов: {total_synced}/{len(channels)}")
            print_info(f"Сообщений: {total_messages}")
            print_info(f"Событий: {total_events_classified}")
            
                                                return result
                                                
                                        except Exception as e:                                    
                                    print_error(f"Ошибка при работе: {e}")
                                    
                                    return None
                                    
                                finally:
                                    
                                    await client.disconnect()

def main():
    print_header()
    
    # Проверим установлены ли зависимости
    try:
        import telethon
        import httpx
    except ImportError as e:
        print_error(f"Отсутствует необходимая библиотека: {e.name}")
        print("Установите зависимости командой:")
        print("  pip install telethon httpx")
        return

    # Запускаем импорт
    result = asyncio.run(import_telegram_messages())
    
    if result:
        print("\n" + "="*60)
        print("РЕЗУЛЬТАТ:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("="*60)
    else:
        print_error("Импорт не удался")
        sys.exit(1)

if __name__ == '__main__':
    main()